﻿/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'en-gb', {
	copy: 'Copyright &copy; $1. All rights reserved.',
	dlgTitle: 'About CKEditor',
	help: 'Check $1 for help.',
	moreInfo: 'For licensing information please visit our web site:',
	title: 'About CKEditor',
	userGuide: 'CKEditor User\'s Guide'
} );
